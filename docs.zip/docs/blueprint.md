# **App Name**: Smart Daily Planner

## Core Features:

- Add Task: Allow users to add tasks with a title, category (Work, Study, Personal), and priority (Low, Medium, High).
- Task Completion: Enable users to mark tasks as complete using a toggle or checkbox.
- Delete Task: Allow users to delete tasks.
- Data Persistence: Persist all task data using Firestore so tasks remain after refresh.

## Style Guidelines:

- Primary color: Soft blue (#A0D2EB) to promote calmness and focus.
- Background color: Very light blue (#F0F8FF), near white, creating a clean and spacious feel.
- Accent color: Light purple (#D0BFFF) to highlight important actions and categories.
- Body and headline font: 'PT Sans', a humanist sans-serif font, to ensure readability and a modern feel.
- Dashboard-style layout, optimized for mobile screens first, then scaled to desktop, using a responsive design approach.
- Simple, consistent icons to represent task categories and priority levels.
- Subtle animations and transitions to provide clear visual feedback and enhance user experience.