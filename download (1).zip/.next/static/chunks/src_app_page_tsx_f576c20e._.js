(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_02be7f17._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_d9c36ae7.js",
  "static/chunks/node_modules_zod_lib_index_mjs_d45abfbb._.js",
  "static/chunks/node_modules_ba312914._.js"
],
    source: "dynamic"
});
